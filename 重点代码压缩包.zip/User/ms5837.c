

#include "bsp.h"


uint16_t C[8];
uint32_t D1, D2;
int32_t TEMP;
int32_t PRESS;
float DEPTH;
float ALTITUDE;

float fluidDensity = 997;



void ms5837_reset(void)
{
	IIC_Start();
	IIC_Send_Byte(MS5837_ADDR);   //CSB�ӵأ�������ַ��0XEC������ 0X76
	IIC_Wait_Ack();
	IIC_Send_Byte(MS5837_RESET);  //���͸�λ����
	IIC_Wait_Ack();
	IIC_Stop();
}

void ms5837_read_prom(void)
{
	u8 inth, intl;
	u8 i;
	
	for(i = 0; i < 8; i++)
	{
		IIC_Start();
		IIC_Send_Byte(MS5837_ADDR);
		IIC_Wait_Ack();
		IIC_Send_Byte(MS5837_PROM_READ + i*2);
		IIC_Wait_Ack();
		IIC_Stop();
		delay_us(10);
		IIC_Start();
		IIC_Send_Byte(MS5837_ADDR + 0x01);  //�������ģʽ
		delay_us(5);
		IIC_Wait_Ack();
		inth = IIC_Read_Byte(1);  		      //��ACK�Ķ�����
		delay_us(5);
		intl = IIC_Read_Byte(0); 			      //���һ���ֽ�NACK
		IIC_Stop();
		C[i] = (((uint16_t)inth << 8) | intl);
	}
}

/***************************************************************************
*����ԭ��:unsigned long MS561101BA_getConversion(void)
*��������:    ��ȡ MS5837 ��ת����� 
*******************************************************************************/
unsigned long ms5837_get_conversion(uint8_t command)
{
	unsigned long conversion = 0;
	u8 temp[3];

	IIC_Start();
	IIC_Send_Byte(MS5837_ADDR); 		//д��ַ
	IIC_Wait_Ack();
	IIC_Send_Byte(command);         //дת������
	IIC_Wait_Ack();
	IIC_Stop();

	delay_ms(30);
	IIC_Start();
	IIC_Send_Byte(MS5837_ADDR); 		//д��ַ
	IIC_Wait_Ack();
	IIC_Send_Byte(MS5837_ADC_READ);	// start read sequence
	IIC_Wait_Ack();
	IIC_Stop();
 
	IIC_Start();
	IIC_Send_Byte(MS5837_ADDR + 0x01);  //�������ģʽ
	IIC_Wait_Ack();
	temp[0] = IIC_Read_Byte(1);  //��ACK�Ķ�����  bit 23-16
	temp[1] = IIC_Read_Byte(1);  //��ACK�Ķ�����  bit 8-15
	temp[2] = IIC_Read_Byte(0);  //��NACK�Ķ����� bit 0-7
	IIC_Stop();
	
	conversion = (unsigned long)temp[0] * 65536 + (unsigned long)temp[1] * 256 + (unsigned long)temp[2];
	return conversion;
}

///***********************************************
//  * @brief  ��ȡ��ѹ
//  * @param  None
//  * @retval None
//************************************************/
void ms5837_get_pressure(void)
{
	D1 = ms5837_get_conversion(MS5837_CONVERT_D1_8192);
	delay_ms(30);
}


/*******************************************************************************
*����ԭ��:void MS561101BA_GetTemperature(void)
*��������:    ��ȡ �¶�ת����� 
*******************************************************************************/

void ms5837_get_temperature(void)
{
	D2 = ms5837_get_conversion(MS5837_CONVERT_D2_8192);
	delay_ms(30);
}


void calculate(void)
{
	float dT;
	float SENS;
	float OFF;
	float SENSi; 
	float OFFi;  
	float Ti;    
	float OFF2;
	float SENS2;
	
	//Terms called
	dT = D2 - (uint32_t)C[5]*256;
	TEMP = 2000 + 1.0*(int64_t)dT*C[6]/8388608;
	
	SENS = (int64_t)C[1]*32768 + 1.0*((int64_t)C[3]*dT)/256;
	OFF = (int64_t)C[2]*65536 + 1.0*((int64_t)C[4]*dT)/128;
	PRESS = (1.0*D1*SENS/(2097152) - OFF)/8192;
	
	//Second order compensation
	if((TEMP/100) < 20)           //Low temp
	{
		Ti = 3.0*(int64_t)(dT)*(int64_t)(dT)/(8589934592);
		OFFi = 3.0*(TEMP - 2000)*(TEMP - 2000)/2;
		SENSi = 5.0*(TEMP - 2000)*(TEMP - 2000)/8;
		if((TEMP/100) < -15)       //Very low temp
		{
			OFFi = OFFi + 7*(TEMP + 1500)*(TEMP + 1500);
			SENSi = SENSi + 4*(TEMP + 1500)*(TEMP + 1500);
		}
	}
	else         //High temp
	{    
		Ti = 2.0*(dT*dT)/(137438953472);
		OFFi = 1.0*(TEMP - 2000)*(TEMP - 2000)/16;
		SENSi = 0;
	}
	
	OFF2 = OFF - OFFi;           //Calculate pressure and temp second order
	SENS2 = SENS - SENSi;
	
	TEMP = (TEMP - Ti) + -350;
	PRESS = ((1.0*(D1*SENS2)/2097152 - OFF2)/8192) + 2360;   //����50�ף���ѹ100.62kpa
	
	DEPTH = (PRESS/10.0*100 - 100620)/(fluidDensity*9.80665);
	
	printf("temp : %.1f��\r\n", TEMP/100.0f);
	printf("press: %.1fmbar\r\n", PRESS/10.0f);
	printf("depth: %.2fm\r\n\r\n", DEPTH);

}


void init_ms5837(void)
{
	ms5837_reset();
	delay_ms(100);
	ms5837_read_prom();
	delay_ms(100);
}

