

#include "bsp.h"


u16 get_current(void)
{	
	float temp;
	u16 current;
	temp = adcData[1] * ADC_DIVISOR;
	current = temp * 21756 - 757;      //mA
	return current;
}

u16 get_voltage(void)
{
	float temp;
	u16 voltage;
	temp = adcData[2] * ADC_DIVISOR;
	voltage = temp * (1 + 4.7 + 10) * 1000;
	return voltage;
}
