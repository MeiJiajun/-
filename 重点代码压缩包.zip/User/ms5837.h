#ifndef _MS5837_H_
#define _MS5837_H_

#define MS5837_ADDR               0xEC
#define MS5837_RESET              0x1E
#define MS5837_ADC_READ           0x00
#define MS5837_PROM_READ          0xA0
#define MS5837_CONVERT_D1_8192    0x4A
#define MS5837_CONVERT_D2_8192    0x5A

#define DEPTH_0                        0x01

void ms5837_reset(void);
void ms5837_read_prom(void);
unsigned long ms5837_get_conversion(uint8_t command);
void ms5837_get_temperature(void);
void ms5837_get_pressure(void);
void calculate(void);
void init_ms5837(void);

#endif
