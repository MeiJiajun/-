/*
*********************************************************************************************************
*
*	ģ������ : 485��ʼ��
*	�ļ����� : bsp_485.h
*	��    �� : V1.0
*	˵    �� : 485��ʼ��
*	
*********************************************************************************************************
*/

#include "bsp.h"

RS485 g_RS485;

/*
*********************************************************************************************************
*	�� �� ��: bsp_Init485
*	����˵��: ����485ͨ�Ŷ˿�,  �ú����� bsp_Init() ���á�
*	��    ��: ��
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void bsp_init_485(unsigned int baudrate)
{
	GPIO_InitTypeDef 	GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;

	RCC_APB1PeriphClockCmd(USARTx_485_RCC, ENABLE);
	RCC_APB2PeriphClockCmd(USARTx_485_GPIO_RCC, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure); 

	USART_DeInit(USARTx_485);

	GPIO_InitStructure.GPIO_Pin = USARTx_485_Tx_GPIO_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(USARTx_485_Tx_GPIO, &GPIO_InitStructure); 

	GPIO_InitStructure.GPIO_Pin = USARTx_485_Rx_GPIO_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(USARTx_485_Tx_GPIO, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure); 

	USART_InitStructure.USART_BaudRate = baudrate;		
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_Init(USARTx_485, &USART_InitStructure); 	
				
	USART_ITConfig(USARTx_485, USART_IT_RXNE, ENABLE);	

	USART_Cmd(USARTx_485, ENABLE);

	SET_485_RX_MODE;
	RS485_Para_Init();
	RS485_GetAddress();
}

/*
*********************************************************************************************************
*	�� �� ��: RS485_GetAddress
*	����˵��: 485��ȡ��ַ
*	��    ��: ��
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void RS485_GetAddress()
{
	unsigned char address = 0;

	address |= GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_15) << 0;
	address |= GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_14) << 1;
	address |= GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_13) << 2;
	
	g_RS485.Receive_Address = 1;
}
/*
*********************************************************************************************************
*	�� �� ��: RS485_Para_Init
*	����˵��: 485������ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void RS485_Para_Init()
{
	u8 i;
	for(i = 0;i < RECEIVE_DATA_LEN;i++)
	{
		g_RS485.Receive_Data[i] = 0;											
	}	
	g_RS485.Receive_HeadFlag = 0;
	g_RS485.Receive_HeadIndex = 0;
	g_RS485.Receive_DataIndex = 0;
	g_RS485.Receive_FrameHead[0] = 0x55;
	g_RS485.Receive_FrameHead[1] = 0xAA;
	g_RS485.Receive_FrameFunction = 0x80;
	
	g_RS485.Send_FrameHead[0] = 0x55;
	g_RS485.Send_FrameHead[1] = 0xAA;
	g_RS485.Send_FrameFunction = 0x90;
	
	for(i = 0;i < SEND_DATA_LEN;i++)
	{
		g_RS485.Send_Data[i] = 0;											
	}
}

u16 sensor_data[15];
/*
*********************************************************************************************************
*	�� �� ��: ���ݴ�������
*	����˵��: �ҳ�11·�ź��е����ֵ����Ȩ����
*	��    ��: ��
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void data_process(void)
{
	u8 i;
	u8 max_data;
	u8 max_index;
	u32 temp = 0;
	float error;
	float p = 1;
	for(i = 0; i < 15; i++)
	{
		sensor_data[i] = adcValue[i]*256/4096;
		//temp += sensor_data[i];
	}
//	p = 1.0*(temp/11)/2000;       //�Ŵ�ϵ��
	p = 0.8;
	/*for(i = 0; i < 15; i++)
	{
		sensor_data[i] = (u16)(1.0*sensor_data[i]/p);   //�Զ����洦�� ƽ��ֵ3000
	}*/
	
	
	/*�ҳ����ֵ �����ź������ֵ�����ݶ��½�����*/
	max_data = sensor_data[0];
	max_index = 0;
	for(i = 1; i < 15; i++)
	{
		if(max_data < sensor_data[i])			
		{
			max_data = sensor_data[i];
			max_index = i;
		}
	}
	sensor_data[max_index] = sensor_data[max_index] + 50;
	//200
	
	//max_data+=50;
	
	
	
	
	for(i = 0; i < max_index - 1; i++)      
	{
		if(sensor_data[i+1] < sensor_data[i])
		{
			sensor_data[i+1] = sensor_data[i];
		}
	}
	
	for(i = 14; i > max_index + 1; i--)     
	{
		if(sensor_data[i-1] < sensor_data[i])
		{
			sensor_data[i-1] = sensor_data[i];
		}
	}
}
/*
*********************************************************************************************************
*	�� �� ��: USARTx_485_IRQHandler
*	����˵��: 485�����жϷ�����
*	��    ��:  ��
*	�� �� ֵ: ��
* Ŀǰ���������⣺��������ʱ����С��30msʱ��������֮��˴ӻ��޷��������ݷ��ص�ַ����Ӧ���ǽ��ճ���������
*********************************************************************************************************
*/ 
void USARTx_485_IRQHandler(void)
{
	u8 dat,i;
	u16 t;
	if(USART_GetITStatus(USARTx_485, USART_IT_RXNE) != RESET)
	{
		USART_ClearITPendingBit(USARTx_485, USART_IT_RXNE);
		dat = USART_ReceiveData(USARTx_485);
				
		if(!g_RS485.Receive_HeadFlag)  //��������ͷ
		{							
			switch(g_RS485.Receive_HeadIndex)  //����ͷ��λ
			{
				case 0:
				if(dat == g_RS485.Receive_FrameHead[0])  //��һλ����ͷ
				{
					g_RS485.Receive_HeadIndex++;
				}
				else
				{
					g_RS485.Receive_HeadIndex = 0;
				}
				break;
				case 1:
				if(dat == g_RS485.Receive_FrameHead[1])  //�ڶ�λ����ͷ
				{
					g_RS485.Receive_HeadFlag = 1;
					g_RS485.Receive_DataIndex = 0;
				}
				else
				{
					g_RS485.Receive_HeadIndex = 0;
				}				
				break;						
				default:
				#ifdef USE_DEBUG
				printf("Error g_RS485.DataIndex!!!\r\n");
				#endif
				break;
			}									
		}	
		else
		{
			g_RS485.Receive_Data[g_RS485.Receive_DataIndex] = dat;
			if(g_RS485.Receive_DataIndex == 0)
			{
				g_RS485.Receive_Sum = g_RS485.Receive_Data[0];				
			}
			else if((g_RS485.Receive_DataIndex >= 1)&&(g_RS485.Receive_DataIndex <= (RECEIVE_DATA_LEN - 2)))
			{
				g_RS485.Receive_Sum ^= g_RS485.Receive_Data[g_RS485.Receive_DataIndex];
			}		
			if(g_RS485.Receive_DataIndex >= RECEIVE_DATA_LEN - 1)  //�������
			{		
				if(g_RS485.Receive_Data[0] == g_RS485.Receive_Address)    //��ַƥ��				
				{  
					if(g_RS485.Receive_Data[RECEIVE_DATA_LEN - 1] == g_RS485.Receive_Sum)  //����ɹ�
					{
						if(g_RS485.Receive_Data[1] == g_RS485.Receive_FrameFunction)  //����֡
						{
							SET_485_TX_MODE; 						
							
							data_process();
							
							g_RS485.Send_Data[0]  = g_RS485.Receive_Address;
							g_RS485.Send_Data[1]  = g_RS485.Send_FrameFunction;
							
							
													
							g_RS485.Send_Data[2]  = (u8)(sensor_data[2]) ;
							g_RS485.Send_Data[3]  = (u8)(sensor_data[3] );
							g_RS485.Send_Data[4]  = (u8)(sensor_data[4] );
							g_RS485.Send_Data[5]  = (u8)(sensor_data[5] );
							g_RS485.Send_Data[6]  = (u8)(sensor_data[6] );
							g_RS485.Send_Data[7]  = (u8)(sensor_data[7] );
							g_RS485.Send_Data[8]  = (u8)(sensor_data[8] );
							g_RS485.Send_Data[9]  = (u8)(sensor_data[9] );
							g_RS485.Send_Data[10]  = (u8)(sensor_data[10] );
							g_RS485.Send_Data[11]  = (u8)(sensor_data[11] );
							g_RS485.Send_Data[12]  = (u8)(sensor_data[12] );
							
							
							
//							g_RS485.Send_Data[2]  = 20;
//							g_RS485.Send_Data[3]  = 25;
//							g_RS485.Send_Data[4]  = 35;
//							g_RS485.Send_Data[5]  = 70;
//							g_RS485.Send_Data[6]  = 90;
//							g_RS485.Send_Data[7]  = 128;
//							g_RS485.Send_Data[8]  = 90;
//							g_RS485.Send_Data[9]  = 70;
//							g_RS485.Send_Data[10]  = 50;
//							g_RS485.Send_Data[11]  = 35;
//							g_RS485.Send_Data[12]  = 20;
							
							g_RS485.Send_Sum = g_RS485.Send_Data[0];
							for(i = 1;i <= 12;i++)
							{
								g_RS485.Send_Sum ^= g_RS485.Send_Data[i];								
							}
							g_RS485.Send_Data[13] = g_RS485.Send_Sum;

							for(t = 0; t < 3000; t++);
							
							RS485_SendData(g_RS485.Send_FrameHead,SEND_HEAD_LEN);						
							RS485_SendData(g_RS485.Send_Data,14);
							
							printf("Send 485 data [90] ok!!!\r\n");
//							
//							g_RS485.Send_Data[2]  = (test_adc[0]>>8) & 0xff;
//							g_RS485.Send_Data[3]  = test_adc[0] & 0xff;
//							g_RS485.Send_Data[4]  = (test_adc[1]>>8) & 0xff;
//							g_RS485.Send_Data[5]  = test_adc[1] & 0xff;
//							g_RS485.Send_Data[6]  = (test_adc[2]>>8) & 0xff;
//							g_RS485.Send_Data[7]  = test_adc[2] & 0xff;
//							g_RS485.Send_Data[8]  = (test_adc[3]>>8) & 0xff;
//							g_RS485.Send_Data[9]  = test_adc[3] & 0xff;
//							g_RS485.Send_Data[10] = (test_adc[4]>>8) & 0xff;
//							g_RS485.Send_Data[11] = test_adc[4] & 0xff;
//							g_RS485.Send_Data[12] = (test_adc[5]>>8) & 0xff;
//							g_RS485.Send_Data[13] = test_adc[5] & 0xff;
//							g_RS485.Send_Data[14] = (test_adc[6]>>8) & 0xff;
//							g_RS485.Send_Data[15] = test_adc[6] & 0xff;
//							g_RS485.Send_Data[16] = (test_adc[7]>>8) & 0xff;
//							g_RS485.Send_Data[17] = test_adc[7] & 0xff;
//							g_RS485.Send_Data[18] = (test_adc[8]>>8) & 0xff;
//							g_RS485.Send_Data[19] = test_adc[8] & 0xff;
//							g_RS485.Send_Data[20] = (test_adc[9]>>8) & 0xff;
//							g_RS485.Send_Data[21] = test_adc[9] & 0xff;
//							g_RS485.Send_Data[22] = (test_adc[10]>>8) & 0xff;
//							g_RS485.Send_Data[23] = test_adc[10] & 0xff;
//							g_RS485.Send_Data[24] = (test_adc[11]>>8) & 0xff;
//							g_RS485.Send_Data[25] = test_adc[11] & 0xff;
//							g_RS485.Send_Data[26] = (test_adc[12]>>8) & 0xff;
//							g_RS485.Send_Data[27] = test_adc[12] & 0xff;
//							g_RS485.Send_Data[28] = (test_adc[13]>>8) & 0xff;
//							g_RS485.Send_Data[29] = test_adc[13] & 0xff;
//							g_RS485.Send_Data[30] = (test_adc[14]>>8) & 0xff;
//							g_RS485.Send_Data[31] = test_adc[14] & 0xff;				
														
//							g_RS485.Send_Sum = g_RS485.Send_Data[0];
//							for(i = 1;i <= SEND_DATA_LEN - 2;i++)
//							{
//								g_RS485.Send_Sum ^= g_RS485.Send_Data[i];								
//							}
//							g_RS485.Send_Data[SEND_DATA_LEN - 1] = g_RS485.Send_Sum;
//							
//							RS485_SendData(g_RS485.Send_FrameHead,SEND_HEAD_LEN);							
//							
//							RS485_SendData(g_RS485.Send_Data,SEND_DATA_LEN);

							for(i = 0;i < RECEIVE_DATA_LEN;i++)
							{
								g_RS485.Receive_Data[i] = 0;											
							}					
							g_RS485.Receive_HeadFlag = 0;
							g_RS485.Receive_HeadIndex = 0;
							g_RS485.Receive_DataIndex = 0;
							
							for(t = 0; t < 3000; t++);
							SET_485_RX_MODE;																					
						}
						else if(g_RS485.Receive_Data[1] == 0x82)  //����֡
						{
							SET_485_TX_MODE; 						
							
							data_process();
							
							g_RS485.Send_Data[0]  = g_RS485.Receive_Address;
							g_RS485.Send_Data[1]  = 0x91;
													
							g_RS485.Send_Data[2]  = (u8)(sensor_data[0] * (1.0*256/4096));
							g_RS485.Send_Data[3]  = (u8)(sensor_data[1] * (1.0*256/4096));
							g_RS485.Send_Data[4]  = (u8)(sensor_data[2] * (1.0*256/4096));
							g_RS485.Send_Data[5]  = (u8)(sensor_data[3] * (1.0*256/4096));
							g_RS485.Send_Data[6]  = (u8)(sensor_data[4] * (1.0*256/4096));
							g_RS485.Send_Data[7]  = (u8)(sensor_data[5] * (1.0*256/4096));
							g_RS485.Send_Data[8]  = (u8)(sensor_data[6] * (1.0*256/4096));
							g_RS485.Send_Data[9]  = (u8)(sensor_data[7] * (1.0*256/4096));
							g_RS485.Send_Data[10]  = (u8)(sensor_data[8] * (1.0*256/4096));
							g_RS485.Send_Data[11]  = (u8)(sensor_data[9] * (1.0*256/4096));
							g_RS485.Send_Data[12]  = (u8)(sensor_data[10] * (1.0*256/4096));
							
//							g_RS485.Send_Data[2]  = 20;
//							g_RS485.Send_Data[3]  = 25;
//							g_RS485.Send_Data[4]  = 35;
//							g_RS485.Send_Data[5]  = 70;
//							g_RS485.Send_Data[6]  = 90;
//							g_RS485.Send_Data[7]  = 128;
//							g_RS485.Send_Data[8]  = 90;
//							g_RS485.Send_Data[9]  = 70;
//							g_RS485.Send_Data[10]  = 50;
//							g_RS485.Send_Data[11]  = 35;
//							g_RS485.Send_Data[12]  = 20;
							
							g_RS485.Send_Sum = g_RS485.Send_Data[0];
							for(i = 1;i <= 12;i++)
							{
								g_RS485.Send_Sum ^= g_RS485.Send_Data[i];								
							}
							g_RS485.Send_Data[13] = g_RS485.Send_Sum;
              
							for(t = 0; t < 3000; t++);
							
							RS485_SendData(g_RS485.Send_FrameHead,SEND_HEAD_LEN);						
							RS485_SendData(g_RS485.Send_Data,14);
							
							printf("Send 485 data [91] ok!!!\r\n");
							
							for(i = 0;i < RECEIVE_DATA_LEN;i++)
							{
								g_RS485.Receive_Data[i] = 0;											
							}	
							g_RS485.Receive_HeadFlag = 0;
							g_RS485.Receive_HeadIndex = 0;
							g_RS485.Receive_DataIndex = 0;
							
							for(t = 0; t < 3000; t++);
							SET_485_RX_MODE;	
						}
						else
						{
							#ifdef USE_DEBUG
							printf("Error g_RS485.FrameFunction!!!\r\n");
							#endif
						}
					}					
					else
					{
						#ifdef USE_DEBUG
						printf("Error g_RS485 Sum!!!\r\n");
						#endif
						for(i = 0;i < RECEIVE_DATA_LEN;i++)
						{
							g_RS485.Receive_Data[i] = 0;											
						}
						g_RS485.Receive_HeadFlag = 0;
						g_RS485.Receive_HeadIndex = 0;
						g_RS485.Receive_DataIndex = 0;
					}
				}
				else
				{
					#ifdef USE_DEBUG
					printf("Error g_RS485.Address!!!\r\n");
					#endif
					for(i = 0;i < RECEIVE_DATA_LEN;i++)
					{
						g_RS485.Receive_Data[i] = 0;											
					}
					g_RS485.Receive_HeadFlag = 0;
					g_RS485.Receive_HeadIndex = 0;
					g_RS485.Receive_DataIndex = 0;
				}
				
			}	
			g_RS485.Receive_DataIndex++;
		}
	}
}

void RS485_SendData(u8 *buff, u8 cnt)
{
	u8 i;
	for(i = 0;i < cnt;i++)
	{
		while(USART_GetFlagStatus(USARTx_485, USART_FLAG_TXE) == RESET);
		USART_SendData(USARTx_485,buff[i]);
	}
}








