/*
*********************************************************************************************************
*
*	ģ������ : ��ʱ��ģ��
*	�ļ����� : bsp_timer.c
*	��    �� : V1.0
*	˵    �� : ����systick��ʱ����Ϊϵͳ�δ�ʱ����ȱʡ��ʱ����Ϊ1ms��
*********************************************************************************************************
*/

#include "bsp.h"

static volatile uint32_t s_uiDelayCount = 0;
static volatile uint8_t s_ucTimeOutFlag = 0;
static void 	bsp_idle(void);

TIME2_T g_time2;


/*
*********************************************************************************************************
*	�� �� ��: bsp_InitTimer
*	����˵��: ����systick�жϣ�����ʼ��������ʱ������
*	��    ��:  ��
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void bsp_init_timer(void)
{
	/*
		����systic�ж�����Ϊ1ms��������systick�жϡ�
		-- SystemCoreClock / 1000  ��ʾ��ʱƵ��Ϊ 1000Hz�� Ҳ���Ƕ�ʱ����Ϊ  1ms
	*/
	SysTick_Config(SystemCoreClock / 1000);
	
	bsp_tim2_init();
	bsp_tim3_init();
	bsp_tim4_init();
}

/*
*********************************************************************************************************
*	�� �� ��: SysTick_ISR
*	����˵��: SysTick�жϷ������ÿ��1ms����1��
*	��    ��:  ��
*	�� �� ֵ: ��
*********************************************************************************************************
*/
extern void bsp_RunPer1ms(void);
extern void bsp_RunPer10ms(void);

void SysTick_Handler(void)
{
	if (s_uiDelayCount > 0)
	{
		if (--s_uiDelayCount == 0)
		{
			s_ucTimeOutFlag = 1;
		}
	}					
}

/*
*********************************************************************************************************
*	�� �� ��: bsp_DelayMS
*	����˵��: ms���ӳ�
*	��    ��:  n : �ӳٳ��ȣ���λ1 ms
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void bsp_delay_ms(uint32_t n)
{
	if (n == 0)
	{
		return;
	}
	else if (n == 1)
	{
		n = 2;
	}
	s_uiDelayCount = n;
	s_ucTimeOutFlag = 0;
	while (1)
	{
		bsp_idle();				
		if (s_ucTimeOutFlag == 1)
		{
			break;
		}			
	}
}

/*
*********************************************************************************************************
*    �� �� ��: bsp_DelayUS
*    ����˵��: us���ӳ�
*    ��    ��:  n : �ӳٳ��ȣ���λ1 us
*    �� �� ֵ: ��
*********************************************************************************************************
*/
void bsp_delay_us(uint32_t n)
{
	uint32_t ticks;
	uint32_t told;
	uint32_t tnow;
	uint32_t tcnt = 0;
	uint32_t reload;

	reload = SysTick->LOAD;                
	ticks = n * (SystemCoreClock / 1000000);	 

	tcnt = 0;
	told = SysTick->VAL;             

	while (1)
	{
		tnow = SysTick->VAL;    
		if (tnow != told)
		{    
			if (tnow < told)
			{
				tcnt += told - tnow;    
			}
			else
			{
				tcnt += reload - tnow + told;    
			}        
			told = tnow;

			if (tcnt >= ticks)
			{
				break;
			}
		}  
	}
} 

/*
*********************************************************************************************************
*    �� �� ��: bsp_idle
*    ����˵��: ���еȴ�
*    ��    ��: ��
*    �� �� ֵ: ��
*********************************************************************************************************
*/
void bsp_idle(void)
{
	;
}


void bsp_tim2_init(void)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseSturcture;

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

	TIM_DeInit(TIM2);										     //????TIM2

	TIM_TimeBaseSturcture.TIM_Period = 5000;				     //????? 10000us = 10ms
	TIM_TimeBaseSturcture.TIM_Prescaler = 0x47;				     //72000000/72 = 1M
	TIM_TimeBaseSturcture.TIM_ClockDivision = 0x00;			     //TIM_CKD_DIV1   TIM2????0
	TIM_TimeBaseSturcture.TIM_CounterMode = TIM_CounterMode_Up;  //????   
	TIM_TimeBaseInit(TIM2,&TIM_TimeBaseSturcture);
											
	TIM_ClearFlag(TIM2, TIM_FLAG_Update);						 //?????
	TIM_ITConfig(TIM2, TIM_IT_Update,ENABLE);
	TIM_Cmd(TIM2, ENABLE);										 //??
}

void TIM2_IRQHandler()          //???10ms
{
	u8 send_data[7];
	u16 voltage, current = 0;
	float roll, pitch, yaw = 0;
	
	if(TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET)
	{ 
		g_time2.time_overflow_100ms++;
		g_time2.time_overflow_1s++;
		
		if(g_time2.time_overflow_100ms >=10)
		{
			g_time2.time_flag_100ms = 1;
			g_time2.time_overflow_100ms = 0;
			bsp_led_toggle(2);
		}
		
		if(g_time2.time_overflow_1s >= 100)
		{
			g_time2.time_flag_1s = 1;				
			g_time2.time_overflow_1s = 0;
		}
		
		if(buf_wireless.receiveflag)             
		{		
			buf_wireless.receiveflag = 0;
			if((buf_wireless.buf[0] == 0xfe) && (buf_wireless.buf[8] == 0xef))  
			{
				if(buf_wireless.buf[1] == 0x01)      //��ͨ������
				{
					//ǰ��
					if(buf_wireless.buf[2] == 0x01)
					{
						forward(buf_wireless.buf[3]);
					}
					else if(buf_wireless.buf[2] == 0x02)
					{
						back(buf_wireless.buf[3]);
					}
					else if(buf_wireless.buf[2] == 0x03)
					{
						stop();
					}
					
					//����
					if(buf_wireless.buf[4] == 0x01)
					{
						turn_left(buf_wireless.buf[5]);
					}
					else if(buf_wireless.buf[4] == 0x02)
					{
						turn_right(buf_wireless.buf[5]);
					}
					else if(buf_wireless.buf[4] == 0x03)
					{
						turn_lr_center();
					}
					
					//����
					if(buf_wireless.buf[6] == 0x01)
					{
						turn_up(buf_wireless.buf[7]);
					}
					else if(buf_wireless.buf[6] == 0x02)
					{
						turn_down(buf_wireless.buf[7]);
					}
					else if(buf_wireless.buf[6] == 0x03)
					{
						turn_ud_center();
					}
					
				}
			}
			clear_buf_wireless();
		}
		
		if(buf_jy901.receiveflag)             
		{
			buf_jy901.receiveflag = 0;
			
//			send_string_debug(buf_jy901.buf, 44);
			if(buf_jy901.buf[0] == 0x55 && buf_jy901.buf[1] == 0x51)
			{
				;
			}
			if(buf_jy901.buf[11] == 0x55 && buf_jy901.buf[12] == 0x52)
			{
				;
			}
			if(buf_jy901.buf[22] == 0x55 && buf_jy901.buf[23] == 0x53)
			{
				roll = 1.0*((buf_jy901.buf[25] << 8)| buf_jy901.buf[24]) / 32768 * 180;
				pitch = 1.0*((buf_jy901.buf[27] << 8)| buf_jy901.buf[26]) / 32768 * 180;
				yaw = 1.0*((buf_jy901.buf[29] << 8)| buf_jy901.buf[28]) / 32768 * 180;
				
				if(roll >= 180) roll = roll - 360;
				if(pitch >= 180) pitch = pitch - 360;
				if(yaw >= 180) yaw = yaw - 360;
				
				printf("%.2f,%.2f,%.2f", roll, pitch, yaw);
			}
			if(buf_jy901.buf[33] == 0x55 && buf_jy901.buf[34] == 0x54)
			{
				;
			}

			clear_buf_jy901();
		}
		
		TIM_ClearITPendingBit(TIM2, TIM_FLAG_Update);
		TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
	}
}

void bsp_tim3_init(void)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseSturcture;
	TIM_OCInitTypeDef  TIM_OCInitStructure; 
	
	u16 CCR3 = 3600;
	u16 CCR4 = 3600; 	
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
	TIM_TimeBaseSturcture.TIM_Period = 47999;				    
	TIM_TimeBaseSturcture.TIM_Prescaler = 29;				    
	TIM_TimeBaseSturcture.TIM_ClockDivision = 0x00;			    
	TIM_TimeBaseSturcture.TIM_CounterMode = TIM_CounterMode_Up; 
	TIM_TimeBaseInit(TIM3,&TIM_TimeBaseSturcture);
	
	/* PWM1 Mode configuration: Channel3 */  
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;             //
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;                
	TIM_OCInitStructure.TIM_Pulse = CCR3;                         // 
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;     //
	TIM_OC3Init(TIM3, &TIM_OCInitStructure);                      //
	TIM_OC3PreloadConfig(TIM3, TIM_OCPreload_Enable);  
	/* PWM1 Mode configuration: Channel4 */  
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;  
	TIM_OCInitStructure.TIM_Pulse = CCR4;                           
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;      
	TIM_OC4Init(TIM3, &TIM_OCInitStructure);                      
	TIM_OC4PreloadConfig(TIM3, TIM_OCPreload_Enable); 
  
	TIM_ARRPreloadConfig(TIM3, ENABLE);                           
	/* TIM3 enable counter */  
	TIM_Cmd(TIM3, ENABLE); 										
}

void bsp_tim4_init(void)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseSturcture;
	TIM_OCInitTypeDef  TIM_OCInitStructure;

	u16 CCR1 = 3600;           
	u16 CCR2 = 3600; 										    
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
	TIM_TimeBaseSturcture.TIM_Period = 47999;				    
	TIM_TimeBaseSturcture.TIM_Prescaler = 29;				    
	TIM_TimeBaseSturcture.TIM_ClockDivision = 0x00;			    
	TIM_TimeBaseSturcture.TIM_CounterMode = TIM_CounterMode_Up; 
	TIM_TimeBaseInit(TIM4,&TIM_TimeBaseSturcture);
	
	/* PWM1 Mode configuration: Channel1 */  
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;             //
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;                
	TIM_OCInitStructure.TIM_Pulse = CCR1;                         // 
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;     //
	TIM_OC1Init(TIM4, &TIM_OCInitStructure);                      //
	TIM_OC1PreloadConfig(TIM4, TIM_OCPreload_Enable);  
	/* PWM1 Mode configuration: Channel2 */  
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;  
	TIM_OCInitStructure.TIM_Pulse = CCR2;                           
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;      
	TIM_OC2Init(TIM4, &TIM_OCInitStructure);                      
	TIM_OC2PreloadConfig(TIM4, TIM_OCPreload_Enable); 
  
	TIM_ARRPreloadConfig(TIM4, ENABLE);                           
	/* TIM4 enable counter */  
	TIM_Cmd(TIM4, ENABLE); 
}

