/*
*********************************************************************************************************
*
*	ģ������ : ͨ�ŵ���
*	�ļ����� : bsp_usart.h
*	��    �� : V1.0
*	˵    �� : ����
*
*********************************************************************************************************
*/

#include "bsp.h"

/*
*********************************************************************************************************
*	�� �� ��: bsp_DebugInit
*	����˵��: ����DEBUG ���ڣ���������
*	��    ��:  ��
*	�� �� ֵ: ��
*********************************************************************************************************
*/ 


void bsp_init_debug(void)
{
	GPIO_InitTypeDef 		GPIO_InitStructure;
	USART_InitTypeDef 	USART_InitStructure;
	 
	RCC_APB2PeriphClockCmd(USARTx_DEBUG_RCC | USARTx_DEBUG_GPIO_RCC, ENABLE);	
	
	GPIO_InitStructure.GPIO_Pin = USARTx_DEBUG_Tx_GPIO_PIN; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;	
	GPIO_Init(USARTx_DEBUG_Tx_GPIO, &GPIO_InitStructure);
	 
	GPIO_InitStructure.GPIO_Pin = USARTx_DEBUG_Rx_GPIO_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(USARTx_DEBUG_Tx_GPIO, &GPIO_InitStructure);
	
	USART_InitStructure.USART_BaudRate = USARTx_DEBUG_BAUDRATE;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

	USART_ITConfig(USARTx_DEBUG, USART_IT_RXNE, ENABLE);
	USART_ITConfig(USARTx_DEBUG, USART_IT_IDLE, ENABLE);

	USART_Init(USARTx_DEBUG, &USART_InitStructure);
	USART_Cmd(USARTx_DEBUG, ENABLE);                    
}

/*
*********************************************************************************************************
*	�� �� ��: USARTx_DEBUG_IRQHandler
*	����˵��: DEBUG �����жϷ�����
*	��    ��:  ��
*	�� �� ֵ: ��
*********************************************************************************************************
*/ 
UART_BUF buf_debug;
u16 Clear_IDLE;

void USARTx_DEBUG_IRQHandler(void)
{	
	if(USART_GetITStatus(USARTx_DEBUG, USART_IT_RXNE) != RESET)
	{
		USART_ClearITPendingBit(USARTx_DEBUG, USART_IT_RXNE);	
		
//		while(USART_GetFlagStatus(USARTx_DEBUG, USART_FLAG_TXE) == RESET);
//		USART_SendData(USARTx_JY901, USART_ReceiveData(USARTx_DEBUG));
		
		if(buf_debug.index >= BUFLEN)
		{
			buf_debug.index = 0;
		}
		else
		{
			buf_debug.buf[buf_debug.index++] = USART_ReceiveData(USARTx_DEBUG);
		}	
		
	}
	else if(USART_GetITStatus(USARTx_DEBUG, USART_IT_IDLE) != RESET)
	{
		Clear_IDLE = USARTx_DEBUG->SR;         
		Clear_IDLE = USARTx_DEBUG->DR;        
		buf_debug.receiveflag = 1; 
	}
}

/****************************************************************
 * ???:clear_buf_uart1()
 * ??  :??uart1????
 * ??  :? 
 * ??  :? 
 * ??  :
 ***************************************************************/
void clear_buf_debug(void)
{
	unsigned int i = 0 ,c ;
	c = BUFLEN +1 ;
	USART_ITConfig(USARTx_DEBUG, USART_IT_RXNE, DISABLE);

	for( i = 0 ; i < c ; i ++)
	{
		buf_debug.buf[i] = 0x00;
	}

	buf_debug.index = 0 ;

	USART_ITConfig(USARTx_DEBUG, USART_IT_RXNE, ENABLE);
}

void send_string_debug(u8 *S, char len)
{
	unsigned char i;
    for(i = 0; i < len; i++)
    {
		while(USART_GetFlagStatus(USARTx_DEBUG, USART_FLAG_TXE) == RESET);
		USART_SendData(USARTx_DEBUG, S[i]);
    }
}


#pragma import(__use_no_semihosting)             
//��׼����Ҫ��֧�ֺ���                 
struct __FILE 
{ 
	int handle; 
}; 

FILE __stdout;       

int _sys_exit(int x) 
{ 
	x = x; 
} 

int fputc(int ch, FILE *f)
{      
	while((USART1->SR&0X40)==0);
	USART1->DR = (u8) ch;  
	return ch;
}
