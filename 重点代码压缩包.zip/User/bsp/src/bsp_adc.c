/*
*********************************************************************************************************
*
*  �ļ�˵����ADC����
*  ��    �ߣ�LiYan
*  ����޸ģ�2018-08-02
*  ʹ��˵��: 5·ADC�źŲɼ���DMA���䣬ÿ·ADC�ɼ�10��ƽ��
*            ADC_SAMPLE_NUM ��ͨ���޸ĸ�ֵ�����ӻ���ٶ�adc�ľ�ֵ������������Ҫ��
*
*********************************************************************************************************
*/

#include "bsp.h"


/*  ADC  DMA�洢���� */
u16 adcRawData[ADC_SAMPLE_NUM][ADC_CHANNELS];	
u16 adcData[ADC_CHANNELS];


/*************************************************************************
*����: void  bsp_init_adc(void)
*���ܣ�ADC��ʼ��
*���ã�bsp_init()
*���ߣ�LiYan
*�޸ģ�2018-08-02
*************************************************************************/
void  bsp_init_adc(void)
{ 	
	ADC_InitTypeDef 	 ADC_InitStructure; 
	GPIO_InitTypeDef 	 GPIO_InitStructure;		
	DMA_InitTypeDef      DMA_InitStructure;
	//NVIC_InitTypeDef 		NVIC_InitStructure;  
		
	/*	��ʼ��ʱ��			*/
	RCC_AHBPeriphClockCmd(RCC_ADC_DMA, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_ALL_ADC, ENABLE );			
	RCC_ADCCLKConfig(RCC_PCLK2_Div6); 							
	DMA_DeInit(DMA1_Channel1);
	/*	ADC  IO������		*/
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;		
		
	GPIO_InitStructure.GPIO_Pin = ADC_GPIO_PIN_ONE;
	GPIO_Init(ADC_GPIO_ONE, &GPIO_InitStructure);	
		
	GPIO_InitStructure.GPIO_Pin = ADC_GPIO_PIN_TWO;	
	GPIO_Init(ADC_GPIO_TWO, &GPIO_InitStructure);	
			

	/*	ADC ��ʼ������		*/
	ADC_DeInit(ADCx);  	
	ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;	
	ADC_InitStructure.ADC_ScanConvMode = ENABLE;	
	ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;	
	ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;	
	ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;	
	ADC_InitStructure.ADC_NbrOfChannel = ADC_CHANNELS;	
	ADC_Init(ADCx, &ADC_InitStructure);	 
	ADC_DMACmd(ADCx, ENABLE);
	
	/*	ADC 15·����������		*/
	ADC_RegularChannelConfig(ADCx, ADC_CHANNEL_IN1,  1,  ADC_SAMPLE_TIME );		
	ADC_RegularChannelConfig(ADCx, ADC_CHANNEL_IN2,  2,  ADC_SAMPLE_TIME );
	ADC_RegularChannelConfig(ADCx, ADC_CHANNEL_IN3,  3,  ADC_SAMPLE_TIME );			

		
	/*	ADC  DMA��������		*/
	DMA_DeInit(ADC_DMAx_CHANNELn);
	DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&ADC1->DR;
	DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)&adcRawData;
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;
	DMA_InitStructure.DMA_BufferSize = ADC_CHANNELS * ADC_SAMPLE_NUM;
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
	DMA_InitStructure.DMA_PeripheralDataSize =  DMA_PeripheralDataSize_HalfWord;
	DMA_InitStructure.DMA_MemoryDataSize =  DMA_MemoryDataSize_HalfWord;
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
	DMA_InitStructure.DMA_Priority = DMA_Priority_VeryHigh;
	DMA_InitStructure.DMA_M2M = DMA_M2M_Disable; 
	DMA_Init(ADC_DMAx_CHANNELn, &DMA_InitStructure);

	/* ��ʱ����DMA�ж�		*/
	/*NVIC_InitStructure.NVIC_IRQChannel =DMA1_Channel1_IRQn;  
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1; 
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure); 	
		
	DMA_ITConfig(ADC_DMAx_CHANNELn,DMA_IT_TC, ENABLE);		
	DMA_ClearITPendingBit(DMA_IT_TC);*/
		
		
	/* ADC������DMA���� ��ADC��ʼ�� */
	ADC_Cmd(ADCx, ENABLE);				
	ADC_ResetCalibration(ADCx);	 
	while(ADC_GetResetCalibrationStatus(ADCx));	
	ADC_StartCalibration(ADCx);	  
	while(ADC_GetCalibrationStatus(ADCx));	 		
	DMA_Cmd(ADC_DMAx_CHANNELn, ENABLE);		
	ADC_SoftwareStartConvCmd(ADCx, ENABLE);	
}	

/*************************************************************************
*����: void DMA1_Channel1_IRQHandler(void)
*���ܣ�DMA�ж�
*���ߣ�LiYan
*�޸ģ�2018-08-02
*************************************************************************/
void DMA1_Channel1_IRQHandler(void)
{
	if(DMA_GetITStatus(DMA1_IT_TC1) != RESET)
	{				
		DMA_ClearITPendingBit(DMA1_IT_TC1);						
	}
}

/*************************************************************************
*����: void update_adc_data(void)
*���ܣ���ȡadcֵ
*������channel ͨ��
*���أ�channel��Ӧ��adcת��ֵ
*���ߣ�LiYan
*�޸ģ�2018-08-02
*************************************************************************/
void update_adc_data(void)
{
	u32 temp;
	u8 i, j;
	for(i = 0; i < ADC_CHANNELS; i++)
	{
		temp = 0;
		for(j = 0; j < ADC_SAMPLE_NUM; j++)
		{
			temp += adcRawData[j][i];
		}
		adcData[i] = temp / ADC_SAMPLE_NUM;
	}
}





