/*
*********************************************************************************************************
*
*	ģ������ : ͨ�ŵ���
*	�ļ����� : bsp_usart.h
*	��    �� : V1.0
*	˵    �� : ����
*
*********************************************************************************************************
*/

#include "bsp.h"

/*
*********************************************************************************************************
*	�� �� ��: bsp_DebugInit
*	����˵��: ����DEBUG ���ڣ���������
*	��    ��:  ��
*	�� �� ֵ: ��
*********************************************************************************************************
*/ 


void bsp_init_jy901(void)
{
	GPIO_InitTypeDef 	GPIO_InitStructure;
	USART_InitTypeDef 	USART_InitStructure;
	
	RCC_APB1PeriphClockCmd(USARTx_JY901_RCC, ENABLE);
	RCC_APB2PeriphClockCmd(USARTx_JY901_GPIO_RCC, ENABLE);	
	
	GPIO_InitStructure.GPIO_Pin = USARTx_JY901_Tx_GPIO_PIN; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;	
	GPIO_Init(USARTx_JY901_Tx_GPIO, &GPIO_InitStructure);
	 
	GPIO_InitStructure.GPIO_Pin = USARTx_JY901_Rx_GPIO_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(USARTx_JY901_Tx_GPIO, &GPIO_InitStructure);
	
	USART_InitStructure.USART_BaudRate = USARTx_JY901_BAUDRATE;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

	USART_ITConfig(USARTx_JY901, USART_IT_RXNE, ENABLE);
	USART_ITConfig(USARTx_JY901, USART_IT_IDLE, ENABLE);	

	USART_Init(USARTx_JY901, &USART_InitStructure);
	USART_Cmd(USARTx_JY901, ENABLE);                    
}

/*
*********************************************************************************************************
*	�� �� ��: USARTx_DEBUG_IRQHandler
*	����˵��: DEBUG �����жϷ�����
*	��    ��:  ��
*	�� �� ֵ: ��
*********************************************************************************************************
*/ 
UART_BUF buf_jy901;

void USARTx_JY901_IRQHandler(void)
{	
	u8 data = 0;
	if(USART_GetITStatus(USARTx_JY901, USART_IT_RXNE) != RESET)
	{
		USART_ClearITPendingBit(USARTx_JY901, USART_IT_RXNE);
		
//		while(USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
//		USART_SendData(USART1, USART_ReceiveData(USARTx_JY901));
		
		if(buf_jy901.index >= BUFLEN)
		{
			buf_jy901.index = 0;
		}
		else
		{
			buf_jy901.buf[buf_jy901.index++] = USART_ReceiveData(USARTx_JY901);
		}
	}
	if(USART_GetITStatus(USARTx_JY901, USART_IT_IDLE) != RESET)
	{
		Clear_IDLE = USARTx_JY901->SR;         
		Clear_IDLE = USARTx_JY901->DR;        
		buf_jy901.receiveflag = 1;
	}
}

void clear_buf_jy901(void)
{
	unsigned int i = 0 ,c ;
	c = BUFLEN +1 ;
	USART_ITConfig(USARTx_JY901, USART_IT_RXNE, DISABLE);

	for( i = 0 ; i < c ; i ++)
	{
		buf_jy901.buf[i] = 0x00;
	}

	buf_jy901.index = 0 ;

	USART_ITConfig(USARTx_JY901, USART_IT_RXNE, ENABLE);
}

