/*
*********************************************************************************************************
*
*	ģ������ : ����
*	�ļ����� : bsp_debug.h
*	��    �� : V1.0
*	˵    �� : ͷ�ļ�
*
*********************************************************************************************************
*/

#ifndef _BSP_DEBUG_H_
#define _BSP_DEBUG_H_

#define USARTx_DEBUG      			    USART1
#define USARTx_DEBUG_BAUDRATE  	        115200

#define USARTx_DEBUG_RCC            	RCC_APB2Periph_USART1
#define USARTx_DEBUG_GPIO_RCC        	RCC_APB2Periph_GPIOA
#define USARTx_DEBUG_Tx_GPIO_PIN        GPIO_Pin_9
#define USARTx_DEBUG_Tx_GPIO            GPIOA
#define USARTx_DEBUG_Rx_GPIO_PIN        GPIO_Pin_10
#define USARTx_DEBUG_Rx_GPIO            GPIOA

#define USARTx_DEBUG_IRQn               USART1_IRQn
#define USARTx_DEBUG_IRQHandler         USART1_IRQHandler

#define BUFLEN 100      

typedef struct _UART_BUF
{
	unsigned char buf[BUFLEN+1];                
	unsigned int index;
	unsigned int receiveflag;
}UART_BUF;


extern UART_BUF buf_debug;
extern u16 Clear_IDLE;

void bsp_init_debug(void);
void send_string_debug(u8 *S, char len);
void clear_buf_debug(void);

#endif
