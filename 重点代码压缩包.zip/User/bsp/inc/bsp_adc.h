#ifndef __BSP_ADC_H
#define __BSP_ADC_H

/*  ADC  DMA  GPIO  ʱ�� */
#define RCC_ALL_ADC		RCC_APB2Periph_GPIOA | RCC_APB2Periph_ADC1 | RCC_APB2Periph_GPIOC
#define RCC_ADC_DMA 	RCC_AHBPeriph_DMA1

/*  ADC  DMA   ���� */
#define ADCx                             ADC1
#define ADC_DMAx_CHANNELn                DMA1_Channel1
#define ADC_DMAx_CHANNELn_IRQn           DMA1_Channel1_IRQn
#define ADC_DMAx_CHANNELn_IRQHANDLER     DMA1_Channel1_IRQHandler

/*  ADC  IO��  */
#define ADC_GPIO_ONE			GPIOA
#define ADC_GPIO_PIN_ONE 		GPIO_Pin_0 | GPIO_Pin_1
	
#define ADC_GPIO_TWO			GPIOC
#define ADC_GPIO_PIN_TWO 	    GPIO_Pin_0

#define ADC_REF_VOLTAGE		    3.3f							/* ADC�ο���ѹ	*/				
#define ADC_DIVISOR				(ADC_REF_VOLTAGE / 4096.0f)		/* ADC����		*/
#define ADC_CHANNELS 			3    	    					/* ADCͨ����	*/
#define ADC_SAMPLE_NUM		    50								/* ADC�������� 	*/
#define ADC_SAMPLE_TIME		    ADC_SampleTime_239Cycles5		/* ADC����ʱ�� 	*/

/* N·��������ӦADC--DMAͨ��	*/
#define	ADC_CHANNEL_IN1		ADC_Channel_0
#define	ADC_CHANNEL_IN2		ADC_Channel_1
#define	ADC_CHANNEL_IN3		ADC_Channel_10


extern u16 adcData[ADC_CHANNELS];

void bsp_init_adc(void);
void update_adc_data(void);

#endif 
