#ifndef __BSP_485_H
#define __BSP_485_H

#define USARTx_485                      USART4

#define USARTx_485_RCC            	    RCC_APB1Periph_USART3
#define USARTx_485_GPIO_RCC            	RCC_APB2Periph_GPIOB|RCC_APB2Periph_GPIOA
#define USARTx_485_Tx_GPIO_PIN          GPIO_Pin_10
#define USARTx_485_Tx_GPIO              GPIOB
#define USARTx_485_Rx_GPIO_PIN          GPIO_Pin_11
#define USARTx_485_Rx_GPIO              GPIOB

#define USARTx_485_IRQn                 USART3_IRQn
#define USARTx_485_IRQHandler     		USART3_IRQHandler
	
#define SET_485_TX_MODE  		        GPIO_SetBits(GPIOA,GPIO_Pin_12)
#define SET_485_RX_MODE   		        GPIO_ResetBits(GPIOA,GPIO_Pin_12)

#define RECEIVE_DATA_LEN                5
#define RECEIVE_HEAD_LEN                2
#define SEND_DATA_LEN                   33
#define SEND_HEAD_LEN                   2

typedef struct{
	u8 Receive_Address;
	u8 Receive_FrameHead[2];
	u8 Receive_FrameFunction;
	u8 Receive_HeadIndex;
	u8 Receive_DataIndex;
	u8 Receive_HeadFlag;
	u8 Receive_Data[15];
	u8 Receive_Sum;
	u8 Receive_Start;
	u8 Receive_Finish;
	
	u8 Send_StartFlag;
	u8 Send_FrameHead[2];
	u8 Send_FrameFunction;
	u8 Send_Data[33];
	u8 Send_Sum;
	
}RS485;

extern RS485 g_RS485;

void bsp_init_485(unsigned int baudrate);
void RS485_GetAddress(void);
void RS485_Para_Init(void);
void RS485_SendData(u8 *buff, u8 cnt);
#endif
