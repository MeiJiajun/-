/*
*********************************************************************************************************
*
*	ģ������ : ��ʱ��ģ��
*	�ļ����� : bsp_timer.h
*********************************************************************************************************
*/

#ifndef __BSP_TIMER_H
#define __BSP_TIMER_H


typedef struct TIME2_T
{
	unsigned int  time_overflow_1s;
	unsigned int  time_flag_1s;
	unsigned int  time_overflow_100ms;  
	unsigned int  time_flag_100ms;
}TIME2_T;

extern TIME2_T g_time2;

void bsp_init_timer(void);
void bsp_tim2_init(void);
void bsp_tim3_init(void);
void bsp_tim4_init(void);
void delay_ms(u16 times);

#endif
