/*
*********************************************************************************************************
*
*	ģ������ : ����
*	�ļ����� : bsp_debug.h
*	��    �� : V1.0
*	˵    �� : ͷ�ļ�
*
*********************************************************************************************************
*/

#ifndef _BSP_WIRELESS_H_
#define _BSP_WIRELESS_H_

#define USARTx_WIRELESS      			    USART2
#define USARTx_WIRELESS_BAUDRATE  	        115200

#define USARTx_WIRELESS_RCC            		RCC_APB1Periph_USART2
#define USARTx_WIRELESS_GPIO_RCC        	RCC_APB2Periph_GPIOA
#define USARTx_WIRELESS_Tx_GPIO_PIN         GPIO_Pin_2
#define USARTx_WIRELESS_Tx_GPIO             GPIOA
#define USARTx_WIRELESS_Rx_GPIO_PIN         GPIO_Pin_3
#define USARTx_WIRELESS_Rx_GPIO             GPIOA

#define USARTx_WIRELESS_IRQn                USART2_IRQn
#define USARTx_WIRELESS_IRQHandler          USART2_IRQHandler

#define WIRELESS_M0_GPIO_RCC        	    RCC_APB2Periph_GPIOB
#define WIRELESS_M0_GPIO_PIN                GPIO_Pin_12
#define WIRELESS_M0_GPIO                    GPIOB

#define WIRELESS_M1_GPIO_RCC        	    RCC_APB2Periph_GPIOB
#define WIRELESS_M1_GPIO_PIN                GPIO_Pin_13
#define WIRELESS_M1_GPIO                    GPIOB


//IO��������	 
#define M0    PBout(12) 
#define M1    PBout(11) 

extern UART_BUF buf_wireless;

void bsp_init_wireless(void);
void send_string_wireless(u8 *S, char len);
void clear_buf_wireless(void);

#endif
