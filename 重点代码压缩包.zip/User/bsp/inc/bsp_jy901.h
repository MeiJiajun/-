/*
*********************************************************************************************************
*
*	ģ������ : ����
*	�ļ����� : bsp_debug.h
*	��    �� : V1.0
*	˵    �� : ͷ�ļ�
*
*********************************************************************************************************
*/

#ifndef _BSP_JY901_H_
#define _BSP_JY901_H_

#define USARTx_JY901      			    USART3
#define USARTx_JY901_BAUDRATE  	        115200

#define USARTx_JY901_RCC            	RCC_APB1Periph_USART3
#define USARTx_JY901_GPIO_RCC        	RCC_APB2Periph_GPIOB
#define USARTx_JY901_Tx_GPIO_PIN        GPIO_Pin_10
#define USARTx_JY901_Tx_GPIO            GPIOB
#define USARTx_JY901_Rx_GPIO_PIN        GPIO_Pin_11
#define USARTx_JY901_Rx_GPIO            GPIOB

#define USARTx_JY901_IRQn               USART3_IRQn
#define USARTx_JY901_IRQHandler         USART3_IRQHandler


extern UART_BUF buf_jy901;

void bsp_init_jy901(void);
void clear_buf_jy901(void);

#endif
