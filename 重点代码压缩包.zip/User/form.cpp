﻿#include "form.h"
#include "ui_form.h"
#include <QDebug>
#include <QFile>
#include <QFileDialog>
#include <QTextStream>
#include <QApplication>
#include <QDir>
#include <QByteArray>
#include <QDesktopServices>

extern QString msg;
//QString Msg = "001c012d";

Form::Form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Form)
{

    ui->setupUi(this);
    pApplication=NULL;
    pWorkBooks=NULL;
    pWorkBook=NULL;
    pSheets=NULL;
    pSheet=NULL;
    buf_len=0;
    client = new myclient;
    connect(client,SIGNAL(dataRcv(QString)),this,SLOT(dataDis(QString)));
}

Form::~Form()
{
    delete ui;
}

void Form::dataDis(QString Msg)
{
    bool ok;
    qDebug()<<"buf is:"<<Msg;

    QString  TempData_1_1 = Msg.mid(2 , 2);
    QString  TempData_1_2 = Msg.mid(4 , 2);
    QString  HumiData_1_1 = Msg.mid(6 , 2);
    QString  HumiData_1_2 = Msg.mid(8 , 2);
    QString  LuxData_1 = Msg.mid(10 , 6);

    QString  TempData_2_1 = Msg.mid(18 , 2);
    QString  TempData_2_2 = Msg.mid(20 , 2);
    QString  HumiData_2_1 = Msg.mid(22 , 2);
    QString  HumiData_2_2 = Msg.mid(24 , 2);
    QString  LuxData_2 = Msg.mid(26 , 6);



    //温度数据处理
    TempData_1_1 = QByteArray::number(TempData_1_1.toLongLong(&ok,18),10);  //hex to Qstring int
    TempData_1_2 = QByteArray::number(TempData_1_2.toLongLong(&ok,16),10);  //hex to Qstring int
    QString  TempData_1 = TempData_1_1+"."+TempData_1_2+"℃";


    TempData_2_1 = QByteArray::number(TempData_2_1.toLongLong(&ok,16),10);  //hex to Qstring int
    TempData_2_2 = QByteArray::number(TempData_2_2.toLongLong(&ok,16),10);  //hex to Qstring int
    QString  TempData_2 = TempData_2_1+"."+TempData_2_2+"℃";

    TempData_3_1 = QByteArray::number(TempData_3_1.toLongLong(&ok,16),10);  //hex to Qstring int
    TempData_3_2 = QByteArray::number(TempData_3_2.toLongLong(&ok,16),10);  //hex to Qstring int
    QString  TempData_3 = TempData_3_1+"."+TempData_3_2+"℃";

    //湿度数据处理
    HumiData_1_1 = QByteArray::number(HumiData_1_1.toLongLong(&ok,16),10);  //hex to Qstring int
    HumiData_1_2 = QByteArray::number(HumiData_1_2.toLongLong(&ok,16),10);  //hex to Qstring int
    QString  HumiData_1 = HumiData_1_1+"."+HumiData_1_2+"%";


    HumiData_2_1 = QByteArray::number(HumiData_2_1.toLongLong(&ok,16),10);  //hex to Qstring int
    HumiData_2_2 = QByteArray::number(HumiData_2_2.toLongLong(&ok,16),10);  //hex to Qstring int
    QString  HumiData_2 = HumiData_2_1+"."+HumiData_1_2+"%";
    HumiData_3_2 = QByteArray::number(HumiData_3_2.toLongLong(&ok,16),10);  //hex to Qstring int
    QString  HumiData_3 = HumiData_3_1+"."+HumiData_3_2+"%";

    LuxData_1 = QByteArray::number(LuxData_1.toLongLong(&ok,16),10);  //hex to Qstring int

    LuxData_2 = QByteArray::number(LuxData_2.toLongLong(&ok,16),10);  //hex to Qstring int

    LuxData_3 = QByteArray::number(LuxData_3.toLongLong(&ok,16),10);  //hex to Qstring int


    qDebug()<<TempData_1;
    qDebug()<<HumiData_1;
    qDebug()<<LuxData_1;

    qDebug()<<TempData_2;
    qDebug()<<HumiData_2;
    qDebug()<<LuxData_2;

    qDebug()<<TempData_3;
    qDebug()<<HumiData_3;
    qDebug()<<LuxData_3;

    buffer_data[buf_len].temp1=TempData_1;
    buffer_data[buf_len].temp2=TempData_2;
    buffer_data[buf_len].temp3=TempData_3;

    buffer_data[buf_len].humi1=HumiData_1;
    buffer_data[buf_len].humi2=HumiData_2;
    buffer_data[buf_len].humi3=HumiData_3;

    buffer_data[buf_len].lux1=LuxData_1;
    buffer_data[buf_len].lux2=LuxData_2;
    buffer_data[buf_len].lux3=LuxData_3;

    QFont font = QFont("Times New Roman",28,5);

    ui->Temp_1->setText(TempData_1);
    ui->Temp_1->setFont(font);
    ui->Temp_2->setText(TempData_2);
    ui->Temp_2->setFont(font);
    ui->Temp_3->setText(TempData_3);
    ui->Temp_3->setFont(font);


    ui->Humi_1->setText(HumiData_1);
    ui->Humi_1->setFont(font);
    ui->Humi_2->setText(HumiData_2);
    ui->Humi_2->setFont(font);
    ui->Humi_3->setText(HumiData_3);
    ui->Humi_3->setFont(font);

    ui->Lux_1->setText(LuxData_1);
    ui->Lux_1->setFont(font);
    ui->Lux_2->setText(LuxData_2);
    ui->Lux_2->setFont(font);
    ui->Lux_3->setText(LuxData_3);
    ui->Lux_3->setFont(font);

    buf_len=buf_len+1;
    msg.clear();
}

void Form::on_pushButton_clicked()
{
    QString fileName=QFileDialog::getSaveFileName(NULL,"save file",".","Excel File(*.xls)");
    SaveExcel(fileName);
}

//生成表格信息
void Form::SaveExcel(const QString &fileName)
{
    int tim;
    //初始化
    pApplication = new QAxObject();
    pApplication->setControl("Excel.Application");
    pApplication->dynamicCall("SetVisible(bool)",false);
    pApplication->setProperty("DisplayAlerts", false);
    pWorkBooks=pApplication->querySubObject("WorkBooks");
    pWorkBooks->dynamicCall("ADD");
    pWorkBook=pApplication->querySubObject("ActiveWorkBook");
    pSheets=pWorkBook->querySubObject("Sheets");
    pSheet=pSheets->querySubObject("Item(int)",1);

    for(tim=0;tim<buf_len;tim++)
    {
        //节点1
        setinformation(tim+2,1,buffer_data[tim].temp1);
        setinformation(tim+2,2,buffer_data[tim].humi1);
        setinformation(tim+2,3,buffer_data[tim].lux1);
        //节点2
        setinformation(tim+2,4,buffer_data[tim].temp2);
        setinformation(tim+2,5,buffer_data[tim].humi2);
        setinformation(tim+2,6,buffer_data[tim].lux2);
        //节点3
        setinformation(tim+2,7,buffer_data[tim].temp3);
        setinformation(tim+2,8,buffer_data[tim].humi3);
        setinformation(tim+2,9,buffer_data[tim].lux3);
    }

    buf_len = 0;

    pWorkBook->dynamicCall("SaveAs(const QString&)",QDir::toNativeSeparators(fileName));
    pWorkBook->dynamicCall("Close(Boolean)",false);
    pApplication->dynamicCall("Quit(void)");
}

void Form::setinformation(int row,int line, QString Information)
{
     pSheet->querySubObject("Cells(int,int)",row,line)->setProperty("Value",Information);
}
