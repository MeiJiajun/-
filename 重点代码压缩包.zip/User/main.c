#include "bsp.h"


int main(void)
{	
	
	/*	 ��ʼ�� 	*/
	bsp_init();	
	bsp_nvic();
	bsp_delay_ms(100);

	init_ms5837();
	init_control();
	
	bsp_led_on(1);
				
	motor_gpio_config();//
	
	while(1)
	{	
		delay_ms(1000);
		ms5837_get_pressure();
		ms5837_get_temperature();
		calculate();
		if(DEPTH>=DEPTH_0)//
		{
			forward(10);
		}
//		update_adc_data();
//		printf("current:%dmA\r\n", get_current());
//		printf("voltage:%dmV\r\n", get_voltage());
	}
} 


