﻿#include "myclient.h"

QString IP; 
int port;   
QString msg;
myclient::myclient(QObject *parent) : QObject(parent)
{
    status = false;
    IP = "192.168.1.128"; 
    port = 8008; 
    this->slotEnter();
    this->slotSend();
}


void myclient::slotEnter()
{

    if(!status)
    {
        tcpSocket = new QTcpSocket(this);
        //检测链接信号
        connect(tcpSocket,SIGNAL(connected()),this,SLOT(slotConnected()));
        //检测如果断开
        connect(tcpSocket,SIGNAL(disconnected()),this,SLOT(slotDisconnected()));
        //检测如果有新可以读信号
        connect(tcpSocket,SIGNAL(readyRead()),this,SLOT(dataReceived()));

        tcpSocket->connectToHost(IP,port);
        //连接服务端
        status=true;
    }
    else
    {
        tcpSocket->disconnectFromHost();

        status=false;
    }
}
//链接后
void myclient::slotConnected()
{

    //int length=0;
}

void myclient::slotSend()
{

    QString msg="22"; //22即查询所有数据
    tcpSocket->write(msg.toLatin1(),msg.length());
}

void myclient::slotDisconnected()
{
}

void myclient::dataReceived()
{
    QString bufRcv;
    while(tcpSocket->bytesAvailable()>0)
    {
        QByteArray datagram;
        datagram.resize(tcpSocket->bytesAvailable());

        tcpSocket->read(datagram.data(),datagram.size()); //读取到的数据存放到datagram中，对于
                                      //字节型数据可以通过  datagram.at(i)查看
        msg.clear();

    }
}
