
#include "bsp.h"

void init_control(void)
{
	motor_gpio_config();
}

u8 f_b_ratio;
void forward(u8 ratio)
{
//	motor_set_ratio(3, 75 - 1.0*ratio/4);
//	motor_set_ratio(4, 75 - 1.0*ratio/4);
	f_b_ratio = 75 - 1.0*ratio/4;
}

void back(u8 ratio)
{
//	motor_set_ratio(3, 75 + 1.0*ratio/4);
//	motor_set_ratio(4, 75 + 1.0*ratio/4);
	f_b_ratio = 75 + 1.0*ratio/4;
}

void stop(void)
{
//	motor_set_ratio(3, 75);
//	motor_set_ratio(4, 75);
	f_b_ratio = 75;
}

void turn_left(u8 ratio)
{
	motor_set_ratio(3, f_b_ratio + 1.0*ratio/4);
	motor_set_ratio(4, f_b_ratio - 1.0*ratio/4);
}

void turn_right(u8 ratio)
{
	motor_set_ratio(3, f_b_ratio - 1.0*ratio/4);
	motor_set_ratio(4, f_b_ratio + 1.0*ratio/4);
}

void turn_lr_center(void)
{
	motor_set_ratio(3, f_b_ratio);
	motor_set_ratio(4, f_b_ratio);
}
	

void turn_up(u8 ratio)
{
	motor_set_ratio(1, 75 - 1.0*ratio/4);
	motor_set_ratio(2, 75 - 1.0*ratio/4);
}

void turn_down(u8 ratio)
{
	motor_set_ratio(1, 75 + 1.0*ratio/4);
	motor_set_ratio(2, 75 + 1.0*ratio/4);
}

void turn_ud_center(void)
{
	motor_set_ratio(1, 75);
	motor_set_ratio(2, 75);
}
