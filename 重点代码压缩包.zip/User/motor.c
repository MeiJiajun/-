
#include "bsp.h"


void motor_gpio_config(void)
{
	GPIO_InitTypeDef GPIO_InitStructure; 
	/* GPIOB clock enable */ 
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);  

	/*GPIOA Configuration: TIM3 channel 3 and 4 as alternate function push-pull */ 
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_0 | GPIO_Pin_1; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;          //????
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
	GPIO_Init(GPIOB, &GPIO_InitStructure); 
	
	/* GPIOB clock enable */ 
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);  

	/*GPIOA Configuration: TIM4 channel 1 and 2 as alternate function push-pull */ 
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_6 | GPIO_Pin_7; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;          //????
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
	GPIO_Init(GPIOB, &GPIO_InitStructure);
}


void motor_set_ratio(u8 channel, u8 pwm_ratio)
{
	switch(channel)
	{
		case 1: TIM4->CCR1 = 48 * pwm_ratio; break;
		case 2: TIM4->CCR2 = 48 * pwm_ratio; break;
		case 3: TIM3->CCR3 = 48 * pwm_ratio; break;
		case 4: TIM3->CCR4 = 48 * pwm_ratio; break;
		default: break;
	}
}
